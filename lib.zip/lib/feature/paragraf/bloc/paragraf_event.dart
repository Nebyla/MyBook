part of 'paragraf_bloc.dart';

@freezed
class ParagrafEvent with _$ParagrafEvent{
  const factory ParagrafEvent.fetch() = _Fetch;
}