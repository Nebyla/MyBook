import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mybook/feature/test/bloc/test_bloc.dart';
import 'package:mybook/feature/test/data/repositories/test_repositories.dart';
import 'package:mybook/feature/test/widgets/answer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'test_bloc_provider.dart';
import '../../../core/ui.dart';

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int? _selectedIndex;
  SharedPreferences? _prefs;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Save test result with ID
  Future<void> _saveTestResult(int testId, bool isPassed) async {
    if (_prefs != null) {
      List<String>? passedTests = _prefs!.getStringList('passedTests');
      passedTests ??= [];
      if (isPassed) {
        if (!passedTests.contains(testId.toString())) {
          passedTests.add(testId.toString());
        }
      } else {
        passedTests.remove(testId.toString());
      }
      await _prefs!.setStringList('passedTests', passedTests);
    }
  }

  void _handleAnswerSelected(int? index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final id = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final repository = TestsRepositoryImp(id['paragraf_id'].toString());
    return TestBlocProvider(
      repository: repository,
      child: Builder(builder: (context) {
        final bloc = TestBlocProvider.of(context)!.bloc;
        bloc.add(TestEvent.fetch());
        return Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.amber,
              title: Row(
                children: [
                  Expanded(
                    child: TextWidget(
                      text: 'Test',
                      color: Colors.black,
                      fontSize: 24,
                    ),
                  ),
                ],
              ),
            ),
            body: BlocBuilder<TestBloc, TestState>(
              bloc: bloc,
              builder: (context, state) {
                return state.maybeWhen(success: (result) {
                  return SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextWidget(
                            text: id['question'].toString(),
                            color: Colors.black,
                            fontSize: 20,
                          ),
                        ),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: result.length,
                          itemBuilder: (context, index) {
                            return RadioListTile<int>(
                              title: Text(result[index].answer),
                              value: index,
                              groupValue: _selectedIndex,
                              onChanged: _handleAnswerSelected,
                            );
                          },
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            if (_selectedIndex != null) {
                              final selectedAnswer = result[_selectedIndex!];
                              final isCorrect = selectedAnswer.answers;
                              await _saveTestResult(id['paragraf_id'], isCorrect);
                              if (isCorrect) {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  content: Text('Правильный ответ!'),
                                  backgroundColor: Colors.green,
                                ));
                                Navigator.of(context)
                                    .popUntil(ModalRoute.withName("/themes"));
                              } else {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  content: Text('Неправильный ответ!'),
                                  backgroundColor: Colors.red,
                                ));
                              }
                            }
                          },
                          child: Text('Подать ответ'),
                        ),
                      ],
                    ),
                  );
                }, loading: () {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }, orElse: () {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                });
              },
            ));
      }),
    );
  }
}
