// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'test_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$TestDTOImpl _$$TestDTOImplFromJson(Map<String, dynamic> json) =>
    _$TestDTOImpl(
      id: (json['id'] as num).toInt(),
      id_paragraf: (json['id_paragraf'] as num).toInt(),
      answer: json['answer'] as String,
      answers: json['answers'] as bool,
    );

Map<String, dynamic> _$$TestDTOImplToJson(_$TestDTOImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'id_paragraf': instance.id_paragraf,
      'answer': instance.answer,
      'answers': instance.answers,
    };
