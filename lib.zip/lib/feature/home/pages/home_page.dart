import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mybook/core/ui.dart';
import 'package:mybook/feature/home/data/repositories/homes_repositories.dart';

import '../bloc/home_bloc.dart';

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  late final HomeBloc bloc;

  @override
  void initState() {
    super.initState();
    final repository = HomesRepositoryImp();
    bloc = HomeBloc(repository: repository);
    bloc.add(HomeEvent.fetch());
  }
  @override
  void dispose() {
    bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Row(
          children: [
            Text('Книги')
          ],
        ),
      ),
      body: BlocBuilder<HomeBloc, HomeState>(
        bloc: bloc,
        builder: (context, state) {
          return state.maybeWhen(success: (result) {
            return ListView.builder(
              itemCount: result.length,
              itemBuilder: (context, index) {
                return BookCard(
                  image: result[index].link,
                  text: result[index].name_book,
                  onTap: () {
                    Navigator.pushNamed(context, '/book', arguments: {
                      'id_book': result[index].id,
                      'name_book': result[index].name_book,
                    });
                  },
                );
              },
            );
          }, loading: () {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }, orElse: () {
            return  CircularProgressIndicator();
          });
        },
      ),
    );
  }
}