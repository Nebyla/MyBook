part of '../../../core/ui.dart';

class BookCard extends StatelessWidget {
  final String text;
  final String image;
  final String companyName;
  final String surname;
  final Color? color;
  final String id;
  final void Function() onTap;

  const BookCard({
    super.key,
    required this.text,
    this.color = Colors.orangeAccent,
    this.companyName = '',
    this.surname = '',
    this.id = '', required this.onTap, required this.image,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(15.0),
      child: GestureDetector(
        onTap: onTap,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Row(
                        children: [
                          SizedBox(
                            width: 150,
                            child: Image.network(
                              image,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                            width: 150,
                            child: TextWidget(
                                text: text,
                                color: Colors.black,
                                fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                    // ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
