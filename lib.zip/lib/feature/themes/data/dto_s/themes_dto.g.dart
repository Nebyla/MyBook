// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'themes_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ThemeDTOImpl _$$ThemeDTOImplFromJson(Map<String, dynamic> json) =>
    _$ThemeDTOImpl(
      id: (json['id'] as num).toInt(),
      name_paragraph: json['name_paragraph'] as String,
    );

Map<String, dynamic> _$$ThemeDTOImplToJson(_$ThemeDTOImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name_paragraph': instance.name_paragraph,
    };
