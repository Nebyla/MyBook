part of 'themes_bloc.dart';

@freezed
class ThemeEvent with _$ThemeEvent {
  const factory ThemeEvent.fetch() = _Fetch;
}
